# Search strings

## PubMed (example)
("cell-free protein synthesis" OR CFPS OR "cell-free expression" OR CFE) AND (reactor OR format OR dialysis OR CECF OR "continuous exchange" OR "continuous flow" OR microfluidic OR droplet OR hydrogel OR compartmentalized OR automated)

## Google Scholar (example)
("cell-free protein synthesis" OR "cell-free expression" OR CFPS OR CFE) (reactor OR format OR dialysis OR CECF OR "continuous exchange" OR "continuous flow" OR microfluidic OR droplet OR hydrogel OR compartmentalized OR automated)

## Suggested date filter
2010-2026 (inclusive)
