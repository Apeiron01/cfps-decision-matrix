| scenario | yield | time | complexity | scalability | automation |
|---|---|---|---|---|---|
| Speed-first | 0.2 | 0.4 | 0.15 | 0.1 | 0.15 |
| Yield-first | 0.45 | 0.15 | 0.1 | 0.15 | 0.15 |
| Low-infra-first | 0.15 | 0.2 | 0.4 | 0.1 | 0.15 |
