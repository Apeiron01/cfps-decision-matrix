| format_class | complexity_proxy | scalability_proxy | automation_proxy |
|---|---|---|---|
| batch | 1 | 2 | 2 |
| dialysis_cecf | 3 | 4 | 2 |
| continuous_flow | 4 | 4 | 3 |
| microfluidic | 5 | 2 | 3 |
| droplet | 4 | 2 | 3 |
| hydrogel_compartmentalized | 3 | 3 | 2 |
| automated_ht | 3 | 5 | 5 |
| others | 3 | 3 | 3 |
