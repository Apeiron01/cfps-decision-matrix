| format_class | Low-infra-first | Speed-first | Yield-first |
|---|---|---|---|
| batch | 0.710163 | 0.671884 | 0.664863 |
| dialysis_cecf | 0.45 | 0.375 | 0.65 |
| hydrogel_compartmentalized | 0.486847 | 0.574129 | 0.385541 |
| microfluidic | 0.338562 | 0.527125 | 0.291422 |
